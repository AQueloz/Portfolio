import os
import pandas as pd
import pycountry
import PySimpleGUI as sg
import time
import threading
from PIL import Image
from supporting_functions import *


# Define headers to simulate Google Chrome browser requests later on
headers = {
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
    "accept-encoding": "gzip, deflate, br",
    "accept-language": "en-GB,en;q=0.9,en-US;q=0.8,ml;q=0.7",
    "cache-control": "max-age=0",
    "uprating-insecure-requests": "1",
    "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/"
                    "71.0.3578.80 Chrome/71.0.3578.80 Safari/537.36",
}




# --------------------------- First window - Parameter input ---------------------------

    
# Define the layout for the parameter input window
layout_1 = [

    [sg.Text('Welcome to FlyHigh, your personal travel agent !')],
    [sg.Text('Please give us some more detail about your trip. Not everything is compulsory, but the more we know, the better !\n')],
    
    [sg.Text('City of departure: '), sg.Input(size=(15, 1), key='-CITYDEP-')],
    [sg.Text('Country of departure: '), sg.Combo(values=[country.name for country in sorted(list(pycountry.countries), key=lambda country: country.name)], key='-COUNTRYDEP-')],
    
    [sg.CalendarButton('FROM', target='-IN-', key='-CALENDAR_BEG-', format=('%Y-%m-%d')),
     sg.Input(key='-IN-', enable_events=True),
     sg.CalendarButton('TO', target='-OUT-', key='-CALENDAR_END-', format=('%Y-%m-%d')),
     sg.Input(key='-OUT-', enable_events=True)],

    [sg.Text('Number of adults: '), sg.Spin(values = [i for i in range(1, 11)], initial_value=1, key='-NBADULT-', size=(6, 10)),
     sg.Text('Number of children: '), sg.Spin(values = [i for i in range(0, 11)], initial_value=0, key='-NBCHILD-', size=(6, 10)),
     sg.Text('Number of rooms: '), sg.Spin(values = [i for i in range(1, 21)], initial_value=1, key='-NBROOM-', size=(6, 10))],

    [sg.Text('From here on, all parameters are completely optional !')],
    
    [sg.Text('Destination: '), sg.Input(size=(15,1), key='-CITYARR-')],
    
    [sg.Text('Cabin class in the plane: '), sg.DropDown(['No preferences', 'ECONOMY', 'BUSINESS'], default_value='ECONOMY', key='-CLASS-')],

    [sg.Text('Range of stars (0 = no preferences): '), sg.Listbox(values=list(range(0, 6)), size=(4, 6), select_mode='multiple', default_values=[0], key='-STARS-')],
    
    [sg.Text('Do you want to avoid stops during the flight* ?'), sg.DropDown(['Yes', 'No'], default_value='No', key='-STOPS-')],

    [sg.Text('Maximum budget allocated (in CHF)**: '), sg.Input(size=(8,1), key='-BUDGET-')],

    [sg.Button('Fly !', button_color=('black','green'), key='-FLY-')],

    [sg.Text('* Allowing stops can both allow more different destinations, and also lead to cheaper options.')],
    [sg.Text('** Not all trips are feasable; take that into consideration when allocating your budget.')]

]

# Create the main window
sg.theme()
window_1 = sg.Window("FlyHigh", layout_1, size = (1200,550), element_justification = 'c',
                   resizable = True)


# Assign base values to calendar dates
date_trip_begin = None
date_trip_end = None

# Event loop to handle events
while True:
    
    event, values = window_1.read()
    if event == sg.WIN_CLOSED:
        time.sleep(1)
        os._exit(0)
        
    elif event == '-CALENDAR_BEG-':
        date_trip_begin = values['-CALENDAR_BEG-']
        window_1['-IN-'].update(value=date_trip_begin.strftime('%Y-%m-%d'))
    elif event == '-CALENDAR_END-':
        date_trip_end = values['-CALENDAR_END-']
        window_1['-OUT-'].update(value=date_trip_end.strftime('%Y-%m-%d'))

    # If the button is pressed, assign values to variables
    elif event == '-FLY-':
        
        date_trip_begin = values['-IN-']
        date_trip_end = values['-OUT-']
        city_departure = values['-CITYDEP-']
        country_departure = values['-COUNTRYDEP-']
        nb_adults = values['-NBADULT-']
        nb_children = values['-NBCHILD-']
        nb_rooms = values['-NBROOM-']
        
        # Define default values dictionary
        default_values = {'-CITYARR-': 'random',
                          '-CLASS-': 'ECONOMY',
                          '-STARS-': [0],
                          '-STOPS-': False,
                          '-BUDGET-': 'max'}
        
        # Get user inputs or default values
        def check_default(key):
            if values[key] != '':
                return values[key]
            else:
                return default_values[key]
            
        city_arrival = check_default('-CITYARR-')
        cabin_class = check_default('-CLASS-')
        range_stars = check_default('-STARS-')
        stops = check_default('-STOPS-')
        max_budget = check_default('-BUDGET-')
        
        break

window_1.close()


# --------------------------- Second window - Confirmation ---------------------------

# Define the layout for the second window / confirmation
layout_2 = [
    
    [sg.Text('The program will start running. Chrome windows should appear and disappear, and some actions will be performed. Please, do not interact with these windows in any way !')],
    [sg.Text('When you are ready, press "Start !"')],
          
    [sg.Button('Start')]
    
]


window_2 = sg.Window("FlyHigh", layout_2, element_justification = 'c',
                   resizable = True)

# Event loop to handle events
while True:
    
    event, values = window_2.read()
    if event == sg.WIN_CLOSED:
        time.sleep(1)
        os._exit(0)
    
    if event == 'Start':
        break

# Close the window
window_2.close()




# --------------------------- Third window - Loading... ---------------------------

# Define the layout for the second window / confirmation
layout_3 = [
    
    [sg.Text('The algorithm started planning your trip ! This should take around 5 minutes.')],
    [sg.Text('If at any point in time you feel like playing a minigame, press the "Minigame" button.')],
    [sg.Text('When you are done playing, you can close the minigame and once the timetable will be created, the program will continue.')],
    
    [sg.Text(' ', key='information')],
    
    [sg.Button('Minigame')]
    
]


window_3 = sg.Window("FlyHigh", layout_3, element_justification = 'c',
                   finalize = True, resizable = True)

information = window_3['information']
    
# Flag variable to keep track of whether the minigame is running or not
minigame_running = False

# Create threads for each function to allow multitasking
flyhigh_thread = threading.Thread(target = flyhigh,
                                  args = (city_departure, country_departure,
                                          date_trip_begin, date_trip_end,
                                          nb_adults, nb_children, nb_rooms,
                                          city_arrival, cabin_class,
                                          range_stars, stops, max_budget,
                                          information))

flyhigh_thread.start()

# Event loop to handle events while the flyhigh() function is running
while flyhigh_thread.is_alive():
    
    event, values = window_3.read(timeout = 1000)
    
    if event == sg.WIN_CLOSED:
        time.sleep(1)
        os._exit(0)
    
    if event == 'Minigame':
        # If minigame is already running, do nothing
        if minigame_running:
            continue
        
        # Create and start a new thread for the minigame function
        minigame()
        minigame_running = True

# Join the flyhigh thread
flyhigh_thread.join()
        
# Close the window
window_3.close()




# --------------------------- Fourth window - Timetable ---------------------------

# Resize the timetable to fit the sg Window
img = Image.open('timetable.png')
width, height = img.size

img_size = (min(width, 1300), 400)
img = img.resize(img_size)
img.save('timetable_rsz.png')

# Get the resized timetable as well as empty lists for storage
recommendations = []
comments = []

layout_4 = [
    
    [sg.Text('Your trip is right here ! Scroll to the right to see the whole schedule.\n IMPORTANT: Please note that the given approximative price included restaurants as well. Thus, \nthe price only serves as an indication and does not entirely reflect the actual price of the trip.')],
    
    [sg.Text('Now, you have a few options.')],
    [sg.Text('- You can ask us for additional recommendations by clicking on the "Recommendation" button and selecting what you want (it will be added to your PDF);')],
    [sg.Text('- You can click on the "Comment" button to add comments below your schedule (it will be added to your PDF);')],
    [sg.Text('- And once you are fully satisfied, you can click on the "Download as PDF" button to get the timetable, recommendations/comments (if you opted for that), and the URL of all chosen activities to book it more easily !')],
    
    [sg.Text('Thank you for using FlyHigh !')],
    
    [sg.Image('total_cost.png')],

    [sg.Image(filename='timetable_rsz.png', size=img_size, key='-TIMETABLE-')],
    
    [
     sg.Button('Recommendation'),
     sg.Button('Comment'),
     sg.Button('Download as PDF')]
    
]


window_4 = sg.Window("FlyHigh", layout_4, element_justification = 'c',
                     resizable = True)

# Event loop to handle events
while True:
    
    event, values = window_4.read()
    
    if event == sg.WIN_CLOSED:
        time.sleep(1)
        os._exit(0)
        
    
    elif event == 'Recommendation':
        layout_recommendation = [[sg.Text(f'Maximum 15 recommendation. Currently: {len(recommendations)}', key = '-NB-')],
                                 [sg.Text('', key = '-STATUS-')],
                                 [sg.Button('Hotels (+5)'),
                                  sg.Button('Restaurants (+5)'),
                                  sg.Button('Activities (+5)'),
                                  sg.Button('OK / Cancel')]]
        window_recommendation = sg.Window('Recommendation', layout_recommendation)
        
        while True:
            event, values = window_recommendation.read()
            
            if event in [sg.WIN_CLOSED, 'OK / Cancel']:
                window_recommendation.close()
                break
             
            elif event == 'Hotels (+5)':
                hotel_recommendation = pd.read_csv('all_hotel_df.csv')
                selected_hotel = pd.read_csv('selected_hotel.csv')
                selected_flight = pd.read_csv('selected_flight.csv')
                try:
                    other_hotels = hotel_recommendation.drop(selected_hotel.index).sample(n = 5)
                    hotel_recommendation.drop(other_hotels.index, inplace = True)
                    for index, row in other_hotels.iterrows():
                        recommendations.append(f"- {row['Name']} ({row['Stars']}*)\nCHF {(float(row['hotel_price']) / float(selected_flight.loc[:, 'actual_nb_nights'].iloc[0])):.2f} per night")
                except:
                    window_recommendation['-STATUS-'].update('No more hotel recommendation available.')
                other_hotels = []
                window_recommendation['-NB-'].update(f'Maximum 15 recommendation. Currently: {len(recommendations)}')
            
            elif event == 'Restaurants (+5)':
                restaurant_recommendation = pd.read_csv('all_restaurant_df.csv')
                selected_restaurants = pd.read_csv('selected_restaurants.csv')
                try:
                    other_restaurants = restaurant_recommendation.drop(selected_restaurants.index).sample(n = 5)
                    restaurant_recommendation.drop(other_restaurants.index, inplace = True)
                    for index, row in other_restaurants.iterrows():
                        recommendations.append(f"- {row['Name']} (Rank: {row['Rank']})\n{row['Cuisine']}\n{row['Approximative Price']}")
                except:
                    window_recommendation['-STATUS-'].update('No more restaurant recommendation available.')
                other_restaurants = []
                window_recommendation['-NB-'].update(f'Maximum 15 recommendation. Currently: {len(recommendations)}')
                
            elif event == 'Activities (+5)':
                activity_recommendation = pd.read_csv('all_activity_df.csv')
                selected_activities = pd.read_csv('selected_activities.csv')
                try:
                    other_activities = activity_recommendation.drop(selected_activities.index).sample(n = 5)
                    activity_recommendation.drop(other_activities.index, inplace = True)
                    for index, row in other_activities.iterrows():
                        recommendations.append(f"- {row['Name']} (Rank: {row['Rank']})\n{row['Type']}\nArea: {row['Area']}")
                except:
                    window_recommendation['-STATUS-'].update('No more activity recommendation available.')
                other_activities = []
                window_recommendation['-NB-'].update(f'Maximum 15 recommendation. Currently: {len(recommendations)}')
        

    elif event == 'Comment':
        layout_comment = [
            [sg.Text('Enter your comments:')],
            [sg.InputText(key='-COMMENT-')],
            [sg.Button('Confirm'), sg.Button('Cancel')]
        ]

        window_comment = sg.Window('Comment', layout_comment)

        while True:
            event, values = window_comment.read()
            if event == sg.WIN_CLOSED or event == 'Cancel':
                window_comment.close()
                break
            elif event == 'Confirm':
                comments.append(values['-COMMENT-'])
                window_comment.close()
                break
    
    
    elif event == 'Download as PDF':
        
        selected_flight = pd.read_csv('selected_flight.csv')
        selected_hotel = pd.read_csv('selected_hotel.csv')
        selected_restaurants = pd.read_csv('selected_restaurants.csv')
        selected_activities = pd.read_csv('selected_activities.csv')
        
        generate_pdf(city_arrival, selected_flight, selected_hotel,
                     selected_restaurants, recommendations, comments)
        window_4.close()
        break

# Close the window
window_4.close()

# Delete the now useless .csv, .xsls, .png and .jpg files created during the process
for filename in os.listdir(os.getcwd()):
    if filename.endswith(".csv") or filename.endswith(".xlsx") or filename.endswith(".png") or filename.endswith(".jpg"):
        if filename != "bestcities.csv":
            os.remove(os.path.join(os.getcwd(), filename))

