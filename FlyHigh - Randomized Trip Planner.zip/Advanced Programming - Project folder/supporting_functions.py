import excel2img
import haversine as hs
import numpy as np
import openpyxl
import os
import pandas as pd
import pycountry
import PySimpleGUI as sg
import random
import requests
import time
from bs4 import BeautifulSoup
from datetime import date, datetime, timedelta
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from PIL import Image, ImageDraw, ImageFont, ImageTk
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas
from reportlab.platypus import Image as PlatypusImage, Paragraph
from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from webdriver_manager.chrome import ChromeDriverManager


# Define headers to simulate Google Chrome browser requests later on
headers = {
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
    "accept-encoding": "gzip, deflate, br",
    "accept-language": "en-GB,en;q=0.9,en-US;q=0.8,ml;q=0.7",
    "cache-control": "max-age=0",
    "uprating-insecure-requests": "1",
    "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/"
                    "71.0.3578.80 Chrome/71.0.3578.80 Safari/537.36",
}



# GENERAL FUNCTIONS
# ---------------------------------

def empty_list_to_nan(lst):
    if lst == []:
        lst.append(np.NaN)
    return lst

def save_trip_desc(text, filename):

    font = ImageFont.truetype('arial.ttf', 25)
    size = font.getsize(text)
    img = Image.new('RGB', size, color='orange')

    draw = ImageDraw.Draw(img)
    draw.text((0, 0), text, font=font, fill='black')

    img.save(filename)

def generate_pdf(city_arrival, selected_flight, selected_hotel, selected_restaurants,
                 recommendations, comments):
    
    # Define the text
    image_path = 'timetable.png'
    
    url_flight = [str(selected_flight.loc[:, 'URL_x'].iloc[0])]
    url_hotel = [f"{selected_hotel.loc[:, 'Name'].iloc[0]}: {selected_hotel.loc[:, 'URL_y'].iloc[0]}"]
    url_restaurants = [f"{row['Name']}: {row['URL']}" for _, row in selected_restaurants.iterrows()]
    url_restaurants.insert(0, 'Selected restaurants (or best recommendations):')
    recommendations.insert(0, 'Recommendations:')
    
    # Define the page dimensions
    PAGE_WIDTH, PAGE_HEIGHT = landscape(A4)
    PAGE_MARGIN = 15 * mm
    CONTENT_WIDTH = PAGE_WIDTH - 2 * PAGE_MARGIN
    CONTENT_HEIGHT = PAGE_HEIGHT - 2 * PAGE_MARGIN
    
    # Create a Canvas object and add the image to it
    pdf_canvas = canvas.Canvas('My FlyHigh trip.pdf', pagesize=landscape(A4))
    
    img = PlatypusImage(image_path)
    img.drawHeight = CONTENT_HEIGHT // 2
    img.drawWidth = CONTENT_WIDTH
    
    img.wrap(CONTENT_WIDTH, CONTENT_HEIGHT // 2)
    img.drawOn(pdf_canvas, PAGE_MARGIN, PAGE_HEIGHT - PAGE_MARGIN - img.drawHeight)
    
    
    # Define the styles
    url_style = ParagraphStyle(name='url', fontSize=6)
    recommendation_style = ParagraphStyle(name='recommendation', fontSize=6)
    comment_style = ParagraphStyle(name='comment', fontSize=10, leading=12)
    
    
    # Add the comments on the first page
    y = PAGE_HEIGHT - PAGE_MARGIN - img.drawHeight - 20 * mm
    
    p = Paragraph('Comments:', comment_style)
    p.wrap(CONTENT_WIDTH, CONTENT_HEIGHT)
    p.drawOn(pdf_canvas, PAGE_MARGIN, y)
    
    for text in comments:
        y += -p.height
        p = Paragraph(text, comment_style)
        p.wrap(CONTENT_WIDTH, CONTENT_HEIGHT)
        p.drawOn(pdf_canvas, PAGE_MARGIN, y)
        
    
    
    # Create a new page and add the rest of the text to it
    pdf_canvas.showPage()
    
    y = PAGE_HEIGHT - PAGE_MARGIN - 5 * mm    
        
    for text_list, style, height in [(url_flight, url_style, 24),
                                     (url_hotel, url_style, -36),
                                     (url_restaurants, url_style, p.height),
                                     (recommendations, recommendation_style, p.height)]:
    
        for text in text_list:
            y += -p.height
            p = Paragraph(text, style)
            p.wrap(CONTENT_WIDTH, CONTENT_HEIGHT)
            p.drawOn(pdf_canvas, PAGE_MARGIN, y)
            
        y += -height
        
    
    # Save the PDF file
    pdf_canvas.save()
    

    

# BEST CITIES
# ---------------------------------

def get_best_cities():

    # Change options so the browser does not appear on the user's screen
    options = webdriver.ChromeOptions()
    options.add_argument("--incognito")

    # Simulate a Chrome browser opening and going to TripAdvisor
    driver = webdriver.Chrome(ChromeDriverManager().install())
    
    driver.get('https://www.worldsbestcities.com/rankings/worlds-best-cities/')
    time.sleep(5)

    # Scroll to the bottom of the page
    last_height = driver.execute_script("return document.body.scrollHeight")
    while True:
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        new_height = driver.execute_script("return document.body.scrollHeight")
        if new_height == last_height:
            break
        last_height = new_height

    # Extract the page source after scrolling to the bottom of the page
    html = driver.execute_script("return document.documentElement.outerHTML")
    driver.quit()
    soup = BeautifulSoup(html, 'html.parser')

    list_of_cities = [str(name.text).split('\n')[1] for name in soup.find_all("div", class_="column-limit-story-1")]


    # Create bestcities.csv, with the current 100 best cities to visit with their rank
    city_name = []
    city_rank = []

    for city in list_of_cities:

        # Get rid of the "Honorable mention" cities
        if city[0].isdigit():

            # Get the name and the rank
            city = city.split('. ')
            city_name.append(city[1])
            city_rank.append(city[0])

    bestcities_df = pd.DataFrame({'City': city_name, 'Rank': city_rank})


    # Get the list of all main cities ranked by Cost of Living Plus Rent ('https://www.numbeo.com/cost-of-living/rankings_current.jsp')

    url = 'https://www.numbeo.com/cost-of-living/rankings_current.jsp'
    response = requests.get(url, headers=headers)
    html = response.content
    soup = BeautifulSoup(html, "html.parser")

    numbeo_cities_name = [str(name.text).split(', ')[0] for name in soup.find_all("td", class_="cityOrCountryInIndicesTable")]
    numbeo_cities_country = [', '.join(str(name.text).split(', ')[1:]) for name in soup.find_all("td", class_="cityOrCountryInIndicesTable")]
    numbeo_cities_col = [row.find_all("td")[4].text.strip() for row in soup.find("table", {"id": "t2"}).find_all("tr")[1:]]

    col_df = pd.DataFrame({'City': numbeo_cities_name, 'Country': numbeo_cities_country, 'Cost of Living Plus Rent': numbeo_cities_col})

    # Handling special cases: 
    # 1. London, Canada
    col_df.drop(col_df.loc[(col_df['City'] == 'London') & (col_df['Country'] == 'Canada')].index, inplace = True)

    # 2. Tel Aviv-Yafo / Seville (Sevilla) / Taiwan (China)
    col_df.replace('Tel Aviv-Yafo', 'Tel Aviv', inplace = True)
    col_df.replace('Seville (Sevilla)', 'Seville', inplace = True)
    col_df.replace('Taiwan (China)', 'Taiwan', inplace = True)

    # Putting everything together
    bestcities_df = pd.merge(bestcities_df, col_df, how = 'left', on = 'City')

    # Removing cities that still do not have a match in the "Cost of Living Plus Rent" DataFrame (NaN)
    bestcities_df = bestcities_df[bestcities_df['Cost of Living Plus Rent'] == bestcities_df['Cost of Living Plus Rent']]

    # Scrape the JSON from the Nominatim website to get the coordinates for each city
    city_latitude = []
    city_longitude = []

    for index, row in bestcities_df.iterrows():

        json_city_name = row['City'].split(' ')
        json_city_country = row['Country'].split(', ')
        for i in range(len(json_city_country)):
            json_city_country[i] = '+'.join(json_city_country[i].split(' '))
        json_city_name_and_country = '+'.join(json_city_name + json_city_country)

        result = requests.get(f'https://nominatim.openstreetmap.org/search?q=%5B%2771%27%2C+%27{json_city_name_and_country}%27%5D&format=json&limit=1')
        result_json = result.json()[0]
        city_latitude.append(result_json['lat'])
        city_longitude.append(result_json['lon'])

    bestcities_df['Latitude'] = city_latitude
    bestcities_df['Longitude'] = city_longitude

    bestcities_df.to_csv('bestcities.csv', index=False)

def get_distance_from_best_cities(city_departure, country_departure, information=None):

    # Get the latitude and longitude of the given city
    json_city_name = city_departure.split(' ')
    json_country_name = country_departure.split(' ')
    json_city_name = '+'.join(json_city_name + json_country_name)
    result = requests.get(f'https://nominatim.openstreetmap.org/search?q=%5B%2771%27%2C+%27{json_city_name}%27%5D&format=json&limit=1')
    result_json = result.json()[0]
    city_lat = result_json['lat']
    city_lon = result_json['lon']
    
    # Check if the file exists
    if not os.path.isfile("bestcities.csv"):
        try:
            get_best_cities()
        except:
            information.update('The website giving us the list of best cities is not accessible. The random option will be deactived.')
            pass
    else:
        # Check if the file was updated in the current year
        creation_time = os.path.getctime("bestcities.csv")
        creation_year = datetime.fromtimestamp(creation_time).year
        current_year = datetime.now().year

        if creation_year != current_year:
            try:
                get_best_cities()
            except:
                pass

    # Load bestcities.csv
    bestcities_df = pd.read_csv('bestcities.csv')

    distances = []
    for index, row in bestcities_df.iterrows():
        dist = hs.haversine((float(city_lat), float(city_lon)), (float(row['Latitude']), float(row['Longitude'])))
        distances.append(dist)

    bestcities_df['Distance to city'] = distances

    return bestcities_df


# TESTING

# print(get_best_cities())
# print(get_distance_from_best_cities('Milan', 'Italy', information=None))



# BOOKING.COM (HOTEL + FLIGHT)
# ---------------------------------

# FLIGHT

def booking_base_url_from_city_flight(city_departure, city_arrival, date_trip_begin, date_trip_end, information=None):
    
    # Change options so the browser does not appear on the user's screen
    options = webdriver.ChromeOptions()
    options.add_argument("--incognito")
    
    # Simulate a Chrome browser opening and going to TripAdvisor
    driver = webdriver.Chrome(ChromeDriverManager().install(), options = options)
    
    driver.get("https://www.booking.com/flights/index.en-gb.html?aid=304142&label=gen173nr-1FCAEoggI46AdIM1gEaCyIAQGYAQ24ARfIAQzYAQHoAQH4AQyIAgGoAgO4AueT4aAGwAIB0gIkZDg1YjU3ZjEtNzI3Yy00ZmUzLWJjZjAtZWQzMWIxNDZkNGYz2AIG4AIB&sid=cdc4e9f6d2a098b8fe5257d9fa5f36de&skip_runway=1")
    time.sleep(4)

    # Delete previous entry in the search bar (due to cookies)
    try:
        flight_previous_search = "#basiclayout > div > div.css-1niqckn > div > div > div > div > div.css-7wh13m > div:nth-child(2) > div > div > div > div > div.css-lgj0h8 > div > button:nth-child(1) > div.css-ztjjo9 > span.css-wp468s > span > span > b"
        
        try:
            previous_search_button = driver.find_element("css selector", flight_previous_search)
        except:
            information.update('Selector flight_previous_search not found. Please update the CSS selector from https://www.booking.com/flights/index.en-gb.html.')
            time.sleep(5)
            os._exit(0)

        previous_search_button.click() 
        time.sleep(0.5)
        
        flight_previous_search_cancel = "#__bui-10 > div > div > div > div > div > div > div.css-n1d439.css-18e6ulj > div > div > div > div > span > span.css-rh2lq6"
        
        previous_search_cancel = driver.find_element("css selector", flight_previous_search_cancel)
        
        previous_search_cancel.click()
    except:
        pass
    
    # Find the search bar and simulate a research
    def send_actions(action_list):
        actions = ActionChains(driver)
        for action in action_list:
            actions.pause(0.25)
            actions.send_keys(action)
            actions.pause(0.25)
        actions.perform()
    
    # Enter the city of departure and city of arrival
    def enter_city_in_booking_flight(css_selector, city):
        search_bar = driver.find_element("css selector", css_selector)
        search_bar.click()
        search_bar.send_keys(city)
        time.sleep(5)
        search_bar.send_keys(Keys.ARROW_DOWN)
        time.sleep(0.5)
        send_actions([Keys.RETURN])
        time.sleep(0.5)
    
    departure_city_selector = "#__bui-10 > div > div > div > div > div > div > div.css-n1d439.css-18e6ulj > div > div > div > div > input"
    enter_city_in_booking_flight(departure_city_selector, city_departure)
    driver.find_element("css selector", "#basiclayout > div > div.css-1niqckn > div > div > div > div > div.css-7wh13m > div:nth-child(2) > div > div > div > div > div.css-lgj0h8 > div > button:nth-child(3)").click()
    arrival_city_selector = "#__bui-12 > div > div > div > div > div > div > div.css-n1d439.css-18e6ulj > div > div > div > div > input"
    enter_city_in_booking_flight(arrival_city_selector, city_arrival)
    
    send_actions([Keys.TAB, Keys.RETURN])
    
    # Enter the date of departure and date of arrival
    def enter_date_in_booking_flight(month_or_day):
        send_actions([month_or_day, Keys.TAB])
        time.sleep(0.5)
              
    enter_date_in_booking_flight(datetime.strptime(date_trip_begin, '%Y-%m-%d').strftime('%b'))
    enter_date_in_booking_flight(date_trip_begin.split('-')[-1].lstrip('0'))
    enter_date_in_booking_flight(datetime.strptime(date_trip_end, '%Y-%m-%d').strftime('%b'))
    enter_date_in_booking_flight(date_trip_end.split('-')[-1].lstrip('0'))

    # Validate and launch base search (with no attribute yet)
    send_actions([Keys.RETURN, Keys.TAB, Keys.RETURN])

    time.sleep(1.5)
    
    # Get the current base URL to then modify it according to the given criteria
    city_url = driver.current_url    
    
    # Close the browser window and return the URL of the search results page
    driver.quit()

    return city_url
    
def get_formatted_url_from_booking_flight(city_departure, city_arrival, date_trip_begin, date_trip_end, 
                                          nb_adults, nb_children, cabin_class='economy', stops = False,
                                          information = None):
    
    base_url = booking_base_url_from_city_flight(city_departure, city_arrival, date_trip_begin, date_trip_end, information)
    
    base_url = base_url.replace('adults=1', f'adults={nb_adults}')
    base_url = base_url.replace('cabinClass=ECONOMY', f'cabinClass={cabin_class.upper()}')
    base_url = base_url.replace('children=', f'children={nb_children}')
    
    base_url += '&locale=en-us'

    # If the user cares about the amount of stops during the flight, stops = True
    if stops:
        base_url += '&stops=0'
    
    return base_url

def get_flight_from_booking(city_departure, city_arrival, date_trip_begin, date_trip_end,
                               nb_adults, nb_children, information, cabin_class='economy', stops=False):

    url = get_formatted_url_from_booking_flight(city_departure, city_arrival,
                                                date_trip_begin, date_trip_end,
                                                nb_adults, nb_children,
                                                cabin_class, stops, information)

    
    # The URL is defined, so let's define empty lists to store the scraped data
    in_departure_airport = []
    in_departure_date = []
    out_departure_airport = []
    out_departure_date = []
    total_price = []
    in_arrival_airport = []
    in_arrival_date = []
    out_arrival_airport = []
    out_arrival_date = []
    in_departure_time = []
    in_arrival_time = []
    out_departure_time = []
    out_arrival_time = []
    in_duration = []
    out_duration = []
    in_stops = []
    out_stops = []
    in_company = []
    out_company = []

    
    # Change options so the browser does not appear on the user's screen
    options = webdriver.ChromeOptions()
    options.add_argument("--incognito")
    
    # Access the website and retrieve the HTML
    driver = webdriver.Chrome(ChromeDriverManager().install(), options = options)
    
    driver.get(url)
    time.sleep(20)
    html = driver.page_source
    soup = BeautifulSoup(html, "html.parser")


    # List of all flights
    flight_all = [name for name in soup.find_all("div", class_="css-4o3ibe")]

    if flight_all == []:
        information.update('The flight list returned empty. If this is unexpected, please update the CSS selector from https://www.booking.com/flights/index.en-gb.html')
        time.sleep(5)
        os._exit(0)
    
    for flight in flight_all:
        
        # Retrieve date and airport for all departures (either on the way in or out)
        departure_dates_and_airports = [str(name.text).split(' . ') for name in flight.find_all("div", class_="css-5nu86q")]
        departure_dates_and_airports = [departure_dates_and_airports[i][j] for i in range(len(departure_dates_and_airports)) for j in range(2)]
        departure_dates_and_airports = [string.replace('\xa0', ' ') for string in departure_dates_and_airports]
        
        in_departure_airport.extend([departure_dates_and_airports[i] for i in range(0, len(departure_dates_and_airports), 4)])
        in_departure_date.extend([departure_dates_and_airports[i] for i in range(1, len(departure_dates_and_airports), 4)])
        out_departure_airport.extend([departure_dates_and_airports[i] for i in range(2, len(departure_dates_and_airports), 4)])
        out_departure_date.extend([departure_dates_and_airports[i] for i in range(3, len(departure_dates_and_airports), 4)])

    
        # Retrieve date and airport for all arrivals (either on the way in or out) + total price for all travellers
        arrival_dates_and_airports_and_price = [str(name.text).split(' . ') for name in flight.find_all("div", class_="css-yyi517")]
        arrival_dates_and_airports_and_price = [elem for sublist in arrival_dates_and_airports_and_price for elem in sublist]
        
        singleprice = [arrival_dates_and_airports_and_price[i] for i in range(4, len(arrival_dates_and_airports_and_price), 5)]
        arrival_dates_and_airports = [x for x in arrival_dates_and_airports_and_price if x not in singleprice]
        arrival_dates_and_airports = [string.replace('\xa0', ' ') for string in arrival_dates_and_airports]
        
        total_price.extend([str(name.text).split(' ')[1] for name in flight.find_all("div", class_="css-vxcmzt")])

        in_arrival_airport.extend([arrival_dates_and_airports[i] for i in range(0, len(arrival_dates_and_airports), 4)])
        in_arrival_date.extend([arrival_dates_and_airports[i] for i in range(1, len(arrival_dates_and_airports), 4)])
        out_arrival_airport.extend([arrival_dates_and_airports[i] for i in range(2, len(arrival_dates_and_airports), 4)])
        out_arrival_date.extend([arrival_dates_and_airports[i] for i in range(3, len(arrival_dates_and_airports), 4)])
    
    
        # Retrieve time (departure and arrival, in and out)
        flight_times = [name.text for name in flight.find_all("div", class_="Text-module__root--variant-strong_1___S8jkH")]
        
        in_departure_time.extend([flight_times[i] for i in range(0, len(flight_times), 4)])
        in_arrival_time.extend([flight_times[i] for i in range(1, len(flight_times), 4)])
        out_departure_time.extend([flight_times[i] for i in range(2, len(flight_times), 4)])
        out_arrival_time.extend([flight_times[i] for i in range(3, len(flight_times), 4)])
        
        
        # Retrieve flight duration and number of stops (in and out)
        duration_and_stops = [str(name.text).split('m') for name in flight.find_all("div", class_="css-1wnqz2m")]
        duration_and_stops = [elem for sublist in duration_and_stops for elem in sublist]
        
        in_duration.extend([duration_and_stops[i] for i in range(0, len(duration_and_stops), 4)])
        out_duration.extend([duration_and_stops[i] for i in range(2, len(duration_and_stops), 4)])
        in_stops.extend([duration_and_stops[i] for i in range(1, len(duration_and_stops), 4)])
        out_stops.extend([duration_and_stops[i] for i in range(3, len(duration_and_stops), 4)])
    
        
        # Retrieve flight company
        in_company_flight = []
        in_companies = flight.find_all("div", attrs={"data-testid": "flight_card_carrier_0"})
        for company in in_companies:
            in_company_flight.append(str(company.text))
        in_company.append(' and '.join(in_company_flight))

        out_company_flight = []
        out_companies = flight.find_all("div", attrs={"data-testid": "flight_card_carrier_1"})
        for company in out_companies:
            out_company_flight.append(str(company.text))
        out_company.append(' and '.join(out_company_flight))


    # Retrieve flight URL for all flights
    url_flight = [url for i in range(len(in_departure_airport))]

    # Close the browser window and return the URL of the search results page
    driver.quit()
    
    
    flight_df = pd.DataFrame({'in_from_airport': in_departure_airport, 'in_dep_date': in_departure_date, 'in_dep_time': in_departure_time,
                              'in_to_airport': in_arrival_airport, 'in_arr_date': in_arrival_date, 'in_arr_time': in_arrival_time,
                              'in_company': in_company, 'in_duration': in_duration, 'in_nb_stops': in_stops,
                              'out_from_airport': out_departure_airport, 'out_dep_date': out_departure_date, 'out_dep_time': out_departure_time,
                              'out_to_airport': out_arrival_airport, 'out_arr_date': out_arrival_date, 'out_arr_time': out_arrival_time,
                              'out_company': out_company, 'out_duration': out_duration, 'out_nb_stops': out_stops,
                              'total_price': total_price, 'URL': url_flight})
    
    flight_df = flight_df.fillna('---')
    
    # Get the first 5 flights to remove the worse ones
    flight_df = flight_df.head(5)
    
    flight_df.to_csv('flight_df.csv', index = False)
    
    return flight_df


# HOTEL

def booking_base_url_from_city_hotel(city, information=None):
    
    # Change options so the browser does not appear on the user's screen
    options = webdriver.ChromeOptions()
    options.add_argument("--incognito")
    
    # Simulate a Chrome browser opening and going to TripAdvisor
    driver = webdriver.Chrome(ChromeDriverManager().install(), options = options)
    
    driver.get("https://www.booking.com/index.en-gb.html?label=gen173bo-1DCAEoggI46AdICVgDaCyIAQGYAQm4ARfIAQzYAQPoAQH4AQOIAgGYAgKoAgO4AvrmwaAGwAIB0gIkYjFmMWY5OWQtZjc1ZS00OGU2LWE1MWEtNGNmMmNjMjIyMWQ52AIE4AIB&sid=2b837eea4921b52a7ecdf5c678949350&lang_changed=1&sb_price_type=total&")
    
    # Find the search bar and simulate a research
    hotel_search_bar = "[placeholder='Where are you going?']"
    try:
        search_bar = driver.find_element("css selector", hotel_search_bar)
    except:
        information.update('Selector hotel_search_bar not found. Please update the CSS selector from https://www.booking.com/index.en-gb.html.')
        time.sleep(5)
        os._exit(0)
    search_bar.send_keys(city)
    time.sleep(4)
    
    # Press the down arrow key to select the first suggestion, press Enter to validate and Enter again to start the search
    search_bar.send_keys(Keys.ARROW_DOWN)
    search_bar.send_keys(Keys.RETURN)
    time.sleep(0.5)
    search_bar.send_keys(Keys.TAB)
    search_bar.send_keys(Keys.RETURN)
    time.sleep(1.5)
    
    # Get the current base URL to then modify it according to the given criteria
    city_url = driver.current_url    
    
    # Close the browser window and return the URL of the search results page
    driver.quit()

    return city_url

def get_formatted_url_from_booking_hotel(city, checkin_date, checkout_date,
                           nb_adults, nb_children, nb_rooms,
                           range_stars=[0], max_budget='max',
                           information=None):
    
    # Get the base URL from the booking_url_from_city function
    base_url = booking_base_url_from_city_hotel(city, information)
    
    # Modify the URL to match the selected criteria
    # Reorganize the URL to facilitate the restructuration
    base_url = base_url.replace('.html?', '.html?&')
    base_url = base_url.split('&')
    base_url.remove('sb=1')
    base_url.remove('src_elem=sb')
    
    # Move the destination strings to the right spot
    for idx in range(len(base_url)):
        if base_url[idx][:3] == 'ss=':
            deststr = base_url[idx:idx+3]
    for key in base_url:
        if key[:4] == 'aid=':
            new_idx = base_url.index(key)
    for string in deststr:
        base_url.remove(string)
        base_url.insert(new_idx, string)
    
    # Change the number of persons and rooms
    for key in base_url:
        if key[:13] == 'group_adults=':
            base_url[base_url.index(key)] = f'group_adults={nb_adults}'
        elif key[:9] == 'no_rooms=':
            base_url[base_url.index(key)] = f'no_rooms={nb_rooms}'
        elif key[:15] == 'group_children=':
            base_url[base_url.index(key)] = f'group_children={nb_children}'
            
    # Add checkin/checkout dates
    for key in base_url:
        if key[:13] == 'group_adults=':
            # Add checkin and checkout dates (format = 'YYYY-MM-DD')
            base_url.insert(base_url.index(key), f'%3D%3D&checkin={checkin_date}&checkout={checkout_date}')
            break
            
    # Add remaining criteria
    base_url.append('nflt=&')
    
    # Add the stars criteria
    criterialist = [f'class%3D{nb}' for nb in range_stars if range_stars != [0]]
    
    # Add the hotel criteria
    criterialist.insert(0, 'ht_id%3D204')
    
    # Add the budget criteria
    criterialist.append(f'price%3DCHF-min-{max_budget}-1')
    
    # Add the automatic sorting option to get hotels ranked according to both rating and price
    criterialist.append('&%3D%3Border%3Dreview_score_and_price&order=review_score_and_price')
    
    # Join everything using the %3B linking word and appending this to the base URL
    criterialist = '%3B'.join(criterialist)
    base_url.append(criterialist)
    
    # Joining the final URL back to its original format
    base_url = '&'.join(base_url)
    base_url = base_url.replace('?&', '?')
    base_url = base_url.replace('&&', '')

    return base_url

def get_hotel_from_booking(city_arrival, checkin_date, checkout_date,
                           nb_adults, nb_children, nb_rooms, information,
                           range_stars=[0], max_budget='max'):
    
    url = get_formatted_url_from_booking_hotel(city_arrival, checkin_date, checkout_date,
                                               nb_adults, nb_children, nb_rooms,
                                               range_stars, max_budget, information)
    
    # The URL is defined, so let's define empty lists to store the scraped data
    hotel_name = []
    hotel_stars = []
    hotel_rating = []
    hotel_review = []
    hotel_price = []
    hotel_url_booking = []

    # Access the website and retrieve the HTML
    # Change options so the browser does not appear on the user's screen
    options = webdriver.ChromeOptions()
    options.add_argument("--incognito")
    
    # Access the website and retrieve the HTML
    driver = webdriver.Chrome(ChromeDriverManager().install(), options = options)
    
    driver.get(url)
    time.sleep(5)
    html = driver.page_source
    soup = BeautifulSoup(html, "html.parser")

    # Retrieve the "big picture" of every hotel on the page, before dividing it into sections later
    hotel_all = [name for name in soup.find_all("div", class_="a1b3f50dcd be36d14cea f7c6687c3d f996d8c258")]
    
    if hotel_all == []:
        information.update('The hotel list returned empty. If this is unexpected, please update the CSS selector from https://www.booking.com')
        time.sleep(5)
        os._exit(0)
    
    for hotel in hotel_all:
        
        # Retrieve all hotel names on the page
        hotel_name.extend(
            empty_list_to_nan([name.text for name in hotel.find_all("div", class_="fcab3ed991 a23c043802")]))

        # Retrieve the stars of all hotels
        hotel_stars_html = [name for name in hotel.find_all("div", class_="e4755bbd60")]
        hotel_stars.extend(
            empty_list_to_nan([string[12] for string in str(hotel_stars_html).split(' ') if string[:12] == 'aria-label="']))
        
        # Retrieve the ratings of all hotels
        hotel_rating.extend(
            empty_list_to_nan([name.text for name in hotel.find_all("div", class_="b5cd09854e d10a6220b4")]))
        
        # Retrieve the number of reviews of all hotels
        hotel_review.extend(
            empty_list_to_nan([str(name.text[:-8]) + ' reviews' for name in hotel.find_all("div", class_="d8eab2cf7f c90c0a70d3 db63693c62")]))
    
        # Retrieve the prices of all hotels
        hotel_price.extend(
            empty_list_to_nan([name.text.split('\xa0')[1] for name in hotel.find_all("span", class_="fcab3ed991 fbd1d3018c e729ed5ab6")]))
    
        # Retrieve the booking.com URLs of all hotels
        hotel_url_booking_html = [name for name in hotel.find_all("a", class_="e13098a59f")]
        hotel_url_booking.extend(
            empty_list_to_nan([string[6:] for string in str(hotel_url_booking_html).split(' ') if string[:5] == 'href=']))


    # Close the browser window and return the URL of the search results page
    driver.quit()


    hotel_df = pd.DataFrame({'Name': hotel_name, 'Stars': hotel_stars, 'Rating': hotel_rating,
                             'Number of reviews': hotel_review, 'Total price': hotel_price, 'URL': hotel_url_booking})
    
    hotel_df = hotel_df.fillna('---')
    
    hotel_df.to_csv('hotel_df.csv', index = False)
    
    return hotel_df


# print(booking_base_url_from_city_hotel('Milan', information=None))
# print(get_formatted_url_from_booking_hotel('Milan', '2023-05-16', '2023-05-26', 5, 3, 2, information=None))
# print(get_hotel_from_booking('Tokyo', '2023-10-12', '2023-10-24', 2, 1, 2, information=None))

# print(booking_base_url_from_city_flight('Geneva', 'Milan', '2023-05-16', '2023-05-26', information=None))
# print(get_formatted_url_from_booking_flight('Zurich', 'New York', '2023-07-11', '2023-07-21', 2, 2, cabin_class='economy', stops = True, information=None))
# print(get_flight_from_booking('Geneva', 'New York', '2023-07-11', '2023-07-21', 2, 2, cabin_class='economy', stops = True, information=None))



# TRIPADVISOR.COM (RESTAURANT + ACTIVITIES)
# ---------------------------------

# GENERAL

def get_formatted_url_from_tripadvisor(city, trip_type, information=None):
    
    if trip_type == 'restaurant':
        base_url = trip_base_url_from_city_restaurant(city, information)
    elif trip_type == 'activity':
        base_url = trip_base_url_from_city_activities(city, information)

    url_list = []
    
    # Create 3 URLs to get the 90 best ranked restaurants/activities, using the trip_url_from_city function
    for i in ['0', '30', '60']:
        skip_url = base_url.split('-')
        skip_url.insert(-2, f'oa{i}')
        skip_url = '-'.join(skip_url)
        url_list.append(skip_url)
        
    return url_list


# RESTAURANT

def trip_base_url_from_city_restaurant(city, information=None):

    # Change options so the browser does not appear on the user's screen
    options = webdriver.ChromeOptions()
    options.add_argument("--incognito")
    
    # Simulate a Chrome browser opening and going to TripAdvisor
    driver = webdriver.Chrome(ChromeDriverManager().install(), options = options)
    
    driver.get("https://www.tripadvisor.com/Restaurants")
    time.sleep(5)
    
    # Find the search bar and simulate a research
    restaurant_search_bar = "[placeholder='City or restaurant name']"
    try:
        search_bar = driver.find_element("css selector", restaurant_search_bar)
    except:
        information.update('Selector restaurant_search_bar not found. Please update the CSS selector from https://www.tripadvisor.com/Restaurants.')
        time.sleep(5)
        os._exit(0)
    time.sleep(1)
    search_bar.send_keys(city)
    time.sleep(2)
    
    # Press the down arrow key to select the first suggestion and then press Enter
    search_bar.send_keys(Keys.ARROW_DOWN)
    search_bar.send_keys(Keys.RETURN)
    time.sleep(1)
    
    city_url = driver.current_url
    
    # Close the browser window and return the URL of the search results page
    driver.quit()

    return city_url

def get_restaurant_from_tripadvisor(city_arrival, information):

    url_list = get_formatted_url_from_tripadvisor(city_arrival, 'restaurant', information)
    
    # Define empty lists to store the scraped data
    restaurant_name = []
    restaurant_rank = []
    restaurant_cuisine = []
    restaurant_rating = []
    restaurant_review = []
    restaurant_dollar = []
    restaurant_url_tripadvisor = []
    
    # Loop through all 3 URLs to fill these lists and create the final DataFrame
    for url in url_list:
        
        # Change options so the browser does not appear on the user's screen
        options = webdriver.ChromeOptions()
        options.add_argument("--incognito")
        
        # Access the website and retrieve the HTML
        driver = webdriver.Chrome(ChromeDriverManager().install(), options = options)
        
        driver.get(url)
        time.sleep(5)
        html = driver.page_source
        soup = BeautifulSoup(html, "html.parser")
    
        restaurant_all = [name for name in soup.find_all("div", class_="roxNU Vt o")]
    
        for restaurant in restaurant_all:
            
            # Retrieve all restaurant names on the page
            restaurant_name_and_rank = \
                empty_list_to_nan([name.text for name in restaurant.find_all("div", class_="RfBGI")])
            restaurant_name.extend(
                empty_list_to_nan([str(elem).split('. ')[-1] for elem in restaurant_name_and_rank]))
            restaurant_rank.extend([int(str(elem).split('. ')[0]) if str(elem).split('. ')[0] != str(elem).split('. ')[-1]
                                    else np.NaN for elem in restaurant_name_and_rank])
        
            # Retrieve all the subtext containing the number of reviews, the cuisine and the dollar amount
            # Here, a different method to compensate for the lack of information has to be used, as the CSS selector is the exact same
            # for review/opening time and cuisine/dollar amount. We use a common selector and try-except clauses.
            review_time_cuisine_dollar = [name.text for name in restaurant.find_all("span", class_="SUszq")]

            # Reviews
            if review_time_cuisine_dollar[0][0].isdigit() is False:
                review_time_cuisine_dollar.insert(0, np.NaN)
            
            # Opening time (has to be done to keep the same order and lenght per restaurant)
            try:
                if review_time_cuisine_dollar[1][:4] not in ['Clos', 'Open']:
                    review_time_cuisine_dollar.insert(1, np.NaN)
            except:
                review_time_cuisine_dollar.insert(1, np.NaN)

            # Cuisine (if any of the other condition is True, meaning that it is not the cuisine)
            try:
                if review_time_cuisine_dollar[2][0].isdigit() \
                        or review_time_cuisine_dollar[2][:4] in ['Clos', 'Open'] \
                        or review_time_cuisine_dollar[2][0] == '$':
                    review_time_cuisine_dollar.insert(2, np.NaN)
            except:
                review_time_cuisine_dollar.insert(2, np.NaN)

            # Dollar amount
            try:
                if review_time_cuisine_dollar[3][0] != '$':
                    review_time_cuisine_dollar.insert(3, np.NaN)
            except:
                review_time_cuisine_dollar.insert(3, np.NaN)
        
            restaurant_cuisine.extend(
                empty_list_to_nan([review_time_cuisine_dollar[i] for i in range(2, len(review_time_cuisine_dollar), 4)
                                   if not (isinstance(review_time_cuisine_dollar[i], str) and '$' in review_time_cuisine_dollar[i])]))
            restaurant_dollar.extend(
                empty_list_to_nan([review_time_cuisine_dollar[i] for i in range(3, len(review_time_cuisine_dollar), 4)]))

            # Retrieve the remaining information about the rating and the TripAdvisor URL
            restaurant_rating.extend(
                empty_list_to_nan([str(name[-3:])+'/5.0' for name in str(restaurant.find_all("svg", class_="UctUV d H0")).split(' ')
                                      if name[:10] == 'aria-label']))
            restaurant_url_tripadvisor.extend(
                empty_list_to_nan(["www.tripadvisor.com" + str(name[6:-1]) for name
                                               in str(restaurant.find_all("div", class_="RfBGI")).split(' ') if name[:6] == 'href="']))
            
        # Close the browser window and return the URL of the search results page
        driver.quit()

    if restaurant_name == []:
        information.update('The restaurant list returned empty. If this is unexpected, please update the CSS selector from https://www.tripadvisor.com/Restaurants')
        time.sleep(5)
        os._exit(0)
    
    restaurant_df = pd.DataFrame({'Name': restaurant_name, 'Rank': restaurant_rank, 'Cuisine': restaurant_cuisine, 'Rating': restaurant_rating,
                                  'Approximative Price': restaurant_dollar, 'URL': restaurant_url_tripadvisor})
    
    restaurant_df = restaurant_df.fillna('---')
    
    restaurant_df.to_csv('restaurant_df.csv', index = False)
    
    return restaurant_df


# ACTIVITIES

def trip_base_url_from_city_activities(city, information=None):
    
    # Change options so the browser does not appear on the user's screen
    options = webdriver.ChromeOptions()
    options.add_argument("--incognito")
    
    # Simulate a Chrome browser opening and going to TripAdvisor
    driver = webdriver.Chrome(ChromeDriverManager().install(), options = options)
    
    driver.get("https://www.tripadvisor.com/Attractions")
    time.sleep(5)
    
    # Find the search bar and simulate a research
    activity_search_bar = "[placeholder='Search a destination, attraction, or activity']"
    try:
        search_bar = driver.find_element("css selector", activity_search_bar)
    except:
        information.update('Selector activity_search_bar not found. Please update the CSS selector from https://www.tripadvisor.com/Attractions.')
        time.sleep(5)
        os._exit(0)
    time.sleep(1)
    search_bar.send_keys(city)
    time.sleep(5)
    
    # Press the down arrow key to select the first suggestion and then press Enter
    search_bar.send_keys(Keys.ARROW_DOWN)
    search_bar.send_keys(Keys.RETURN)
    time.sleep(1)     
    
    city_url = driver.current_url
    
    # Close the browser window and return the URL of the search results page
    driver.quit()

    return city_url

def get_activity_from_tripadvisor(city_arrival, information):

    url_list = get_formatted_url_from_tripadvisor(city_arrival, 'activity', information)
    
    activity_name = []
    activity_rank = []
    activity_type = []
    activity_area = []
    
    # Loop through all 3 URLs to fill these lists and create the final DataFrame
    for url in url_list:
        
        # Change options so the browser does not appear on the user's screen
        options = webdriver.ChromeOptions()
        options.add_argument("--incognito")
        
        # Access the website and retrieve the HTML
        driver = webdriver.Chrome(ChromeDriverManager().install(), options = options)
        
        driver.get(url)
        time.sleep(5)
        html = driver.page_source
        soup = BeautifulSoup(html, "html.parser")
    
        activity_all = [name for name in soup.find_all("div", class_="hZuqH")]

        for activity in activity_all:

            # Retrieve all restaurant names on the page
            activity_name_and_rank = \
                empty_list_to_nan([name.text for name in activity.find_all("div", class_="XfVdV o AIbhI")])
            activity_name.extend(
                empty_list_to_nan([str(elem).split('. ')[-1] for elem in activity_name_and_rank]))
            activity_rank.extend([str(elem).split('. ')[0] if str(elem).split('. ')[0] != str(elem).split('. ')[-1]
                                    else np.NaN for elem in activity_name_and_rank])

            # Retrieve the subtext containing the type of activity and the area in which it is located
            activity_type_one = \
                empty_list_to_nan([name.text for name in activity.find_all("div", class_="alPVI eNNhq PgLKC tnGGX yzLvM") if name.text[:17] != 'Admission tickets'])
            activity_area_one = \
                empty_list_to_nan([str(name.text).split('•')[0] for name in activity.find_all("div", class_="bRMrl _Y K")])
            
            # Small trick to determine whether there is an area or if it is simply additional, non-useful information
            try:
                if activity_area_one[0] in activity_type_one[0]:
                    activity_type_one = [activity_type_one[0].split(activity_area_one[0])[0]]
            except:
                pass

            activity_type.extend(activity_type_one)
            activity_area.extend(activity_area_one)
            
        # Close the browser window and return the URL of the search results page
        driver.quit()

    if activity_name == []:
        information.update('The activity list returned empty. If this is unexpected, please update the CSS selector from https://www.tripadvisor.com/Attractions')
        time.sleep(5)
        os._exit(0)

    activity_area = [str(activity).replace('\x80¢Open now', '') for activity in activity_area]
    activity_area = [str(activity).replace('Open now', str(np.NaN)) for activity in activity_area]

    
    activity_df = pd.DataFrame({'Name': activity_name, 'Rank': activity_rank, 'Type': activity_type, 'Area': activity_area})
    
    activity_df = activity_df.fillna('---')
    
    activity_df.to_csv('activity_df.csv', index = False)
    
    return activity_df


# TESTING

# print(trip_base_url_from_city_restaurant('Tokyo', information=None))
# print(get_formatted_url_from_tripadvisor('Tokyo', 'restaurant', information=None))
# print(get_restaurant_from_tripadvisor('Tokyo', information=None))

# print(trip_base_url_from_city_activities('Tokyo', information=None))
# print(get_formatted_url_from_tripadvisor('Tokyo', 'activity', information=None))
# print(get_activity_from_tripadvisor('Tokyo', information=None))



# GLOBAL FUNCTIONS
# ---------------------------------

# SELECTION

def select_flight_and_hotel(iscityrandom, bestcities_df, city_departure,
                            city_arrival, date_trip_begin, date_trip_end, nb_adults,
                            nb_children, nb_rooms, range_stars, cabin_class,
                            stops, max_budget, remaining_budget, nb_nights,
                            information):
    
    i = 0
    # Allow 5 tries before asking the user to select new parameters
    while i < 5:
                
        flight_df = get_flight_from_booking(city_departure, city_arrival, date_trip_begin,
                                            date_trip_end, nb_adults, nb_children, information,
                                            cabin_class, stops)
        
        # Check if the DataFrame is empty
        if flight_df.empty:
            
            if iscityrandom:
                city_arrival = bestcities_df[bestcities_df['City'] != city_arrival].sample(n=1)['City'].values[0]
                i += 1
            else:
                information.update(f'There are no flights available for the {city_arrival} at the given dates. Try again with different parameters.')
                time.sleep(5)
                os._exit(0)
                
        else:
    
            hotel_df = get_hotel_from_booking(city_arrival, date_trip_begin, date_trip_end,
                                              nb_adults, nb_children, nb_rooms, information,
                                              range_stars, max_budget)
            
            # Check if the DataFrame is empty
            if hotel_df.empty:
                
                if iscityrandom:
                    city_arrival = bestcities_df[bestcities_df['City'] != city_arrival].sample(n=1)['City'].values[0]
                    i += 1
                else:
                    information.update(f'There are no hotel available for {city_arrival} at the given dates. Try again with different parameters.')
                    time.sleep(5)
                    os._exit(0)
            
            else:
            
                # Convert the flight_df and hotel_df price columns to a easy-to-manipulate float
                flight_df['flight_price'] = flight_df['total_price'].str.extract(r"([\d,\.]+)")
                flight_df['flight_price'] = flight_df['flight_price'].apply(
                    lambda x: str(x).replace('.', '').replace(',', '.')).astype(float)
            
                hotel_df['hotel_price'] = hotel_df['Total price'].apply(
                    lambda x: str(x).replace(',', '')).astype(float)
                
                flight_df.drop('total_price', axis = 1, inplace = True)
                hotel_df.drop('Total price', axis = 1, inplace = True)
                
                # If the budget is not limited, we basically pick the best flight and one of the five best hotels available
                if max_budget == 999999:
                    
                    # Get the best flight
                    selected_flight = flight_df.iloc[0, :]
                    budget_flight = float(selected_flight.loc[0, 'flight_price'])
                    
                    # Update the number of nights according to the chosen flights, to get the right hotel price
                    actual_nb_nights = (datetime.strptime(flight_df.loc[0, 'out_dep_date'], '%b %d') - datetime.strptime(flight_df.loc[0, 'in_arr_date'], '%b %d')).days
                    flight_df['actual_nb_nights'] = actual_nb_nights
                    hotel_df['hotel_price'] = round(hotel_df['hotel_price'] * (actual_nb_nights / nb_nights), 2)
                    
                    # Get one of the five best hotels
                    five_best_hotels = hotel_df.head(5)
                    selected_hotel = five_best_hotels.sample(n = 1)
                    budget_hotel = float(selected_hotel.loc[0, 'hotel_price'])
                    
                    hotel_df.to_csv('all_hotel_df.csv', index = False)
                    
                    # Update the budget and break out of the loop
                    flight_and_hotel_budget = budget_hotel + budget_flight
                    
                    return selected_flight, selected_hotel, remaining_budget
            
                    
                # If the budget is limited, we limit the total price of flight and hotel to the remaining budget and pick from that slice of DataFrame
                else:
                    
                    # Add the actual_nb_nights column to flight_df so the hotel price choice is not biased
                    flight_df['actual_nb_nights'] = (datetime.strptime(flight_df.loc[0, 'out_dep_date'], '%b %d') - datetime.strptime(flight_df.loc[0, 'in_arr_date'], '%b %d')).days
                    
                    # Since the combinations are limited, we can easily create a new DataFrame of all possible combinations of flight and hotels
                    # We have to add a dummy variable 'key' to combine them more easily, that we drop once merged
                    flight_and_hotel_df = pd.merge(flight_df.assign(key=0), hotel_df.assign(key=0), on='key').drop('key', axis=1)
                    
                    # We modify the total_price_for_manipulation_y (hotel) column according to the actual_nb_nights for the corresponding flight
                    flight_and_hotel_df['hotel_price'] = round(flight_and_hotel_df['hotel_price'] * flight_and_hotel_df['actual_nb_nights'] / nb_nights, 2)
                    
                    # We add the total_price_for_manipulation columns
                    flight_and_hotel_df['price_flight_hotel'] = flight_and_hotel_df['flight_price'] + flight_and_hotel_df['hotel_price']
            
                    # We can now pick a random row from this DataFrame that matches the remaining allocated budget
                    matching_flight_and_hotel_df = flight_and_hotel_df[flight_and_hotel_df['price_flight_hotel'] <= remaining_budget*0.7]
                    if not matching_flight_and_hotel_df.empty:
                        selected_flight_and_hotel = matching_flight_and_hotel_df.sample(n = 1)
                        i = 6
                    else:
                        if iscityrandom:
                            city_arrival = bestcities_df[bestcities_df['City'] != city_arrival].sample(n=1)['City'].values[0]
                            i += 1
                        else:
                            information.update('There are no possible combination of flight and hotel for the given parameters that match your budget limit.\nWe picked the cheapest combination available, but the budget will not be respected.')
                            try:
                                matching_flight_and_hotel_df = flight_and_hotel_df.sort_values('price_flight_hotel', ascending=True).iloc[:10]
                                selected_flight_and_hotel = flight_and_hotel_df.sort_values('price_flight_hotel', ascending=True).iloc[[0]]
                                i = 6
                            except:
                                information.update('It is impossible to find a trip matching your criteria. Start again with different parameters.')
                                time.sleep(5)
                                os._exit(0)
                                

    if i == 5:
        information.update('We could not find any random destination that matched your criteria.\nPlease restart the program and give us a bigger margin, either for budget or dates !')
        time.sleep(5)
        os._exit(0)
            
    # We extract the selected flight, the selected hotel and the combined budget
    selected_flight = selected_flight_and_hotel.iloc[:, 0:21]
    selected_hotel = selected_flight_and_hotel.iloc[:, 21:27]
    flight_and_hotel_budget = selected_flight_and_hotel.iloc[0, -1]
    
    all_hotel_df = matching_flight_and_hotel_df.iloc[:, 21:27]
    all_hotel_df.to_csv('all_hotel_df.csv', index = False)

    # Deduce the cost from the remaining budget
    remaining_budget += -flight_and_hotel_budget

    return selected_flight, selected_hotel, remaining_budget, city_arrival

def select_restaurants(city_arrival, nb_adults, nb_children, remaining_budget, nb, information):
    
    restaurant_df = get_restaurant_from_tripadvisor(city_arrival, information)
    
    restaurant_df.to_csv('all_restaurant_df.csv', index = True)
    
    # Define the selection and pricing helping function
    def select_and_match_restaurant_price(nb):
                
        selected_restaurants = restaurant_df.sample(n = nb)
        
        budget_restaurants = 0.00
        
        price_mapping = {'$': lambda a, c: 10 * a + 7.50 * c,
                         '$ - $$': lambda a, c: 15 * a + 10 * c,
                         '$$': lambda a, c: 20 * a + 12.50 * c,
                         '$$ - $$$': lambda a, c: 25 * a + 15 * c,
                         '---': lambda a, c: 25 * a + 15 * c,
                         '$$$': lambda a, c: 30 * a + 17.50 * c,
                         '$$$ - $$$$': lambda a, c: 35 * a + 20 * c,
                         '$$$$': lambda a, c: 40 * a + 25 * c}

        # Loop through each row and calculate the corresponding value for the price string
        for index, row in selected_restaurants.iterrows():
            
            price_string = row['Approximative Price']
            budget_restaurants += price_mapping[price_string](nb_adults, nb_children)
            
        return selected_restaurants, float(budget_restaurants)

    i = 0
    budget_restaurants = remaining_budget + 1
    
    # Allow 5 tries before continuing with the selection and warning the user of the budget limit
    while (remaining_budget < budget_restaurants) and (i < 5):
        selected_restaurants, budget_restaurants = select_and_match_restaurant_price(nb)
        i += 1

    if i == 5:
        information.update('The approximative restaurant budget could not be respected.\nWe still proceeded with the planning of your trip, but be aware that the budget might be a bit higher than allowed.')
        pass
    
    selected_restaurants.to_csv('selected_restaurants.csv')
    
    remaining_budget += -budget_restaurants

    return selected_restaurants, remaining_budget

def select_activities(city_arrival, nb, information):
    
    activity_df = get_activity_from_tripadvisor(city_arrival, information)
    
    activity_df.to_csv('all_activity_df.csv', index = True)

    selected_activities = activity_df.sample(n = nb)

    return selected_activities

def select_schedule(city_departure, country_departure, date_trip_begin, date_trip_end, nb_adults, nb_children, nb_rooms,
           city_arrival='random', cabin_class='ECONOMY', range_stars=[0], stops=False, max_budget='max',
           information=None):
    
    
    iscityrandom = True if city_arrival == 'random' else False
    
    # Determine the city if random is chosen
    if iscityrandom:
            
        bestcities_df = get_distance_from_best_cities(city_departure, country_departure, information)
        
        # Select the city based on estimated cost of travel
        # This cannot be precise, but the whole point is to reduce the possibility of having to re-run it many times.
        # Therefore, we used three different trip ideas to create a very basic estimation of the cost, based on
        # the time before the trip, the distance between the two cities and the cost of living and rent index.
        days_before = (datetime.strptime(date_trip_begin, '%Y-%m-%d') - datetime.combine(date.today(), datetime.min.time())).days
        trip_days = (datetime.strptime(date_trip_end, '%Y-%m-%d') - datetime.strptime(date_trip_begin, '%Y-%m-%d')).days
        
        bestcities_df['Estimated cost'] = (bestcities_df['Distance to city'] * 0.1 + bestcities_df['Cost of Living Plus Rent'] * 1.75 * trip_days - 1.4 * days_before)*max(1, (nb_adults + nb_children)*0.65)*1.4
        
        
        if max_budget == 'max':
            bestcities_df = bestcities_df.nlargest(50, 'Estimated cost')
            city_arrival = bestcities_df.sample(n=1)['City'].values[0]
            
        else:
            # Since the estimation is not perfect, we allow a small margin of minimum 5 cities in the list
            if len(bestcities_df[bestcities_df["Estimated cost"] < float(max_budget)]) >= 5:
                bestcities_df = bestcities_df[bestcities_df["Estimated cost"] < float(max_budget)]
            else:
                bestcities_df = bestcities_df.sort_values('Estimated cost', ascending=True).head(5)
            city_arrival = bestcities_df.sample(n=1)['City'].values[0]
            
    else:
        
        bestcities_df = None
            
    # Define a few additional variables
    nb_nights = (datetime.strptime(date_trip_end, '%Y-%m-%d') - datetime.strptime(date_trip_begin, '%Y-%m-%d')).days
    
    initial_budget = int(max_budget) if max_budget != 'max' else 999999
    remaining_budget = initial_budget


    # Get the flight and hotel
    
    selected_flight, selected_hotel, remaining_budget, city_arrival = select_flight_and_hotel(iscityrandom, bestcities_df,
                                                                                              city_departure, city_arrival,
                                                                                              date_trip_begin, date_trip_end, nb_adults,
                                                                                              nb_children, nb_rooms, range_stars,
                                                                                              cabin_class, stops, max_budget,
                                                                                              remaining_budget, nb_nights, information)
    
    
    # Get restaurants
        
    selected_restaurants, remaining_budget = select_restaurants(
            city_arrival, nb_adults, nb_children, remaining_budget, (nb_nights+1)*2, information)
      
    
    # Get activities
    
    selected_activities = select_activities(city_arrival, (nb_nights+1)*2, information)
    
    
    # Get the total cost of the trip and save it as an image for later
    total_cost = initial_budget - remaining_budget
    save_trip_desc(f'This trip to {city_arrival} will cost you around CHF {int(total_cost)}.', 'total_cost.png')
        
    
    selected_flight.to_csv('selected_flight.csv', index = True)
    selected_hotel.to_csv('selected_hotel.csv', index = True)
    selected_activities.to_csv('selected_activities.csv', index = True)
    selected_restaurants.to_csv('selected_restaurants.csv', index = True)

    return selected_flight, selected_hotel, selected_activities, selected_restaurants


# TIMETABLE

def style_table(df, date_trip_begin, date_trip_end, color1 = '24C2A8', color2 = 'E6ECEB'):
    
    # Convert it to an excel file to style is more easily, and load it
    df.to_excel('timetable.xlsx', index=True)
    wb = openpyxl.load_workbook('timetable.xlsx')
    ws = wb['Sheet1']

    # Merge cells in a column with the same value as the previous one
    start_date = datetime.strptime(date_trip_begin, '%Y-%m-%d')
    end_date = datetime.strptime(date_trip_end, '%Y-%m-%d')
    date_list = [start_date + timedelta(days=x) for x in range((end_date-start_date).days + 1)]
    
    for col in range(2, len(date_list) + 3):
        prev_value = None
        start_row = 2
        end_row = 2
        for row in ws.iter_rows(min_row=2, max_row=ws.max_row, min_col=col, max_col=col):
            cell_value = row[0].value
            if cell_value != prev_value:
                if end_row > start_row:
                    ws.merge_cells(start_row=start_row, end_row=end_row, start_column=col, end_column=col)
                start_row = row[0].row
                end_row = row[0].row
            else:
                end_row = row[0].row
            prev_value = cell_value
        
        # Since the loop stops at the last row without checking the if-statement, merge the remaining cells
        if end_row > start_row:
            ws.merge_cells(start_row=start_row, end_row=end_row, start_column=col, end_column=col)

    
    # Styling the timetable
    font = Font(name='Calibri', size=12, bold=True)
    alignment = Alignment(horizontal='center', vertical='center')
    border1 = Border(left=Side(style='thick'), right=Side(style='thick'), top=Side(style='thick'), bottom=Side(style='thick'))
    border2 = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))

    # Set font, alignment, background color and border for the data/header row
    for cell in ws[1]:
        cell.font = font
        cell.alignment = alignment
        cell.fill = PatternFill(start_color=color1, end_color=color1, fill_type='solid')
        cell.border = border1
    
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.font = font
            cell.alignment = alignment
            cell.fill = PatternFill(start_color=color2, end_color=color2, fill_type='solid')
            cell.border = border2
    
    # Auto-fit column widths
    for col in ws.columns:
        max_length = 0
        column = get_column_letter(col[0].column)
        for cell in col:
            try:
                content = str(cell.value).split('\n')
                for line in content:
                    if len(line) > max_length:
                        max_length = len(line)
            except:
                pass
        ws.column_dimensions[column].width = max_length + 1
        
    # Show the text on multiple lines, as intended
    for row in ws.rows:
        for cell in row:
            cell.alignment = cell.alignment.copy(wrap_text=True)


    # Save the table as an image
    wb.save('timetable.xlsx')
    excel2img.export_img('timetable.xlsx','timetable.png','Sheet1', None)
    
def create_timetable(selected_flight,
                     selected_hotel,
                     selected_activities,
                     selected_restaurants,
                     date_trip_begin,
                     date_trip_end,
                     color1 = '24C2A8',
                     color2 = 'E6ECEB'):
    
    # Convert the strings to datetime objects
    start_date = datetime.strptime(date_trip_begin, '%Y-%m-%d')
    end_date = datetime.strptime(date_trip_end, '%Y-%m-%d')
    
    # Generate a list of all dates between the start and end dates
    date_list = [start_date + timedelta(days=x) for x in range((end_date-start_date).days + 1)]
    
    # Create an empty dataframe with row indices from '0h' to '23h'
    row_index = [str(i) + ':00' for i in range(24)]
    timetable = pd.DataFrame(index=row_index)
    
    # Add columns for each date in the date list, with column names as the date in YYYY-MM-DD format
    for date_ in date_list:
        col_name = datetime.strftime(date_, '%Y-%m-%d')
        timetable[col_name] = pd.Series(dtype=float)

    # Add the selected hotel to the DataFrame
    for i in range(0, timetable.shape[1]-1):
        timetable.loc['21:00':'23:00', timetable.columns[i]] = f"{selected_hotel.loc[:, 'Name'].iloc[0]} ({selected_hotel.loc[:, 'Stars'].iloc[0]}*)\nCHF {(float(selected_hotel.loc[:, 'hotel_price'].iloc[0]) / float(selected_flight.loc[:, 'actual_nb_nights'].iloc[0])):.2f} per night and per room"
    for i in range(1, timetable.shape[1]):
        timetable.loc['0:00':'7:00', timetable.columns[i]] = f"{selected_hotel.loc[:, 'Name'].iloc[0]} ({selected_hotel.loc[:, 'Stars'].iloc[0]}*)\nCHF {(float(selected_hotel.loc[:, 'hotel_price'].iloc[0]) / float(selected_flight.loc[:, 'actual_nb_nights'].iloc[0])):.2f} per night and per room"    
    
    # Add the selected restaurants to the DataFrame
    for i in range(0, timetable.shape[1]):
        try:
            random_row = selected_restaurants.sample(n=1)
            timetable.loc['12:00':'13:00', timetable.columns[i]] = f"{random_row['Name'].iloc[0]} (Rank: {random_row['Rank'].iloc[0]})\n{random_row['Cuisine'].iloc[0]}\n{random_row['Approximative Price'].iloc[0]}"
            index_label = random_row.index[0]
            selected_restaurants = selected_restaurants.drop(index_label)
    
            random_row = selected_restaurants.sample(n=1)
            timetable.loc['19:00':'20:00', timetable.columns[i]] = f"{random_row['Name'].iloc[0]} (Rank: {random_row['Rank'].iloc[0]})\n{random_row['Cuisine'].iloc[0]}\n{random_row['Approximative Price'].iloc[0]}"
            index_label = random_row.index[0]
            selected_restaurants = selected_restaurants.drop(index_label)
        except:
            pass
        
    # Add the selected activities to the DataFrame
    for i in range(0, timetable.shape[1]):
        try:
            random_row = selected_activities.sample(n=1)
            timetable.loc['8:00':'11:00', timetable.columns[i]] = f"{random_row['Name'].iloc[0]} (Rank: {random_row['Rank'].iloc[0]})\n{random_row['Type'].iloc[0]}\nArea: {random_row['Area'].iloc[0]}"
            index_label = random_row.index[0]
            selected_activities = selected_activities.drop(index_label)
    
            random_row = selected_activities.sample(n=1)
            timetable.loc['14:00':'18:00', timetable.columns[i]] = f"{random_row['Name'].iloc[0]} (Rank: {random_row['Rank'].iloc[0]})\n{random_row['Type'].iloc[0]}\nArea: {random_row['Area'].iloc[0]}"
            index_label = random_row.index[0]
            selected_activities = selected_activities.drop(index_label)
        except:
            pass

    # Add the selected flight
    # Take the departure/arrival date (%b %d), convert it to the column format (%Y-%m-%d')
    in_dep_date = str(datetime.strftime(datetime.strptime(str(start_date)[:4] + selected_flight.loc[:, 'in_dep_date'].iloc[0], '%Y%b %d'), '%Y-%m-%d'))
    in_arr_date = str(datetime.strftime(datetime.strptime(str(start_date)[:4] + selected_flight.loc[:, 'in_arr_date'].iloc[0], '%Y%b %d'), '%Y-%m-%d'))
    out_dep_date = str(datetime.strftime(datetime.strptime(str(start_date)[:4] + selected_flight.loc[:, 'out_dep_date'].iloc[0], '%Y%b %d'), '%Y-%m-%d'))
    out_arr_date = str(datetime.strftime(datetime.strptime(str(start_date)[:4] + selected_flight.loc[:, 'out_arr_date'].iloc[0], '%Y%b %d'), '%Y-%m-%d'))

    # Take the departure/arrival time ('%I:%M %p'), extract the hour component
    in_dep_time = str(datetime.strftime(datetime.strptime(selected_flight.loc[:, 'in_dep_time'].iloc[0], '%I:%M %p'), '%H:00')).lstrip('0')
    in_arr_time = str(datetime.strftime(datetime.strptime(selected_flight.loc[:, 'in_arr_time'].iloc[0], '%I:%M %p'), '%H:00')).lstrip('0')
    out_dep_time = str(datetime.strftime(datetime.strptime(selected_flight.loc[:, 'out_dep_time'].iloc[0], '%I:%M %p'), '%H:00')).lstrip('0')
    out_arr_time = str(datetime.strftime(datetime.strptime(selected_flight.loc[:, 'out_arr_time'].iloc[0], '%I:%M %p'), '%H:00')).lstrip('0')

    # Add the flights to the DataFrame
    if in_dep_date == in_arr_date:
        timetable.loc[in_dep_time:in_arr_time, in_dep_date] = f"{selected_flight.loc[:, 'in_from_airport'].iloc[0]} - {selected_flight.loc[:, 'in_to_airport'].iloc[0]}\n{selected_flight.loc[:, 'in_dep_time'].iloc[0]} - {selected_flight.loc[:, 'in_arr_time'].iloc[0]} ({selected_flight.loc[:, 'in_duration'].iloc[0]})\n{selected_flight.loc[:, 'in_nb_stops'].iloc[0]}, {selected_flight.loc[:, 'in_company'].iloc[0]}\nCHF {(selected_flight.loc[:, 'flight_price'].iloc[0]/2):.2f} per flight"
    else:
        timetable.loc[in_dep_time:, in_dep_date] = f"{selected_flight.loc[:, 'in_from_airport'].iloc[0]} - {selected_flight.loc[:, 'in_to_airport'].iloc[0]}\n{selected_flight.loc[:, 'in_dep_time'].iloc[0]} - {selected_flight.loc[:, 'in_arr_time'].iloc[0]} ({selected_flight.loc[:, 'in_duration'].iloc[0]})\n{selected_flight.loc[:, 'in_nb_stops'].iloc[0]}, {selected_flight.loc[:, 'in_company'].iloc[0]}\nCHF {(selected_flight.loc[:, 'flight_price'].iloc[0]/2):.2f} per flight"
        timetable.loc[:in_arr_time, in_arr_date] = f"{selected_flight.loc[:, 'in_from_airport'].iloc[0]} - {selected_flight.loc[:, 'in_to_airport'].iloc[0]}\n{selected_flight.loc[:, 'in_dep_time'].iloc[0]} - {selected_flight.loc[:, 'in_arr_time'].iloc[0]} ({selected_flight.loc[:, 'in_duration'].iloc[0]})\n{selected_flight.loc[:, 'in_nb_stops'].iloc[0]}, {selected_flight.loc[:, 'in_company'].iloc[0]}\nCHF {(selected_flight.loc[:, 'flight_price'].iloc[0]/2):.2f} per flight"
        
    if out_dep_date == out_arr_date:
        timetable.loc[out_dep_time:out_arr_time, out_dep_date] = f"{selected_flight.loc[:, 'out_from_airport'].iloc[0]} - {selected_flight.loc[:, 'out_to_airport'].iloc[0]}\n{selected_flight.loc[:, 'out_dep_time'].iloc[0]} - {selected_flight.loc[:, 'out_arr_time'].iloc[0]} ({selected_flight.loc[:, 'out_duration'].iloc[0]})\n{selected_flight.loc[:, 'out_nb_stops'].iloc[0]}, {selected_flight.loc[:, 'out_company'].iloc[0]}\nCHF {(selected_flight.loc[:, 'flight_price'].iloc[0]/2):.2f} per flight"
    else:
        timetable.loc[out_dep_time:, out_dep_date] = f"{selected_flight.loc[:, 'out_from_airport'].iloc[0]} - {selected_flight.loc[:, 'out_to_airport'].iloc[0]}\n{selected_flight.loc[:, 'out_dep_time'].iloc[0]} - {selected_flight.loc[:, 'out_arr_time'].iloc[0]} ({selected_flight.loc[:, 'out_duration'].iloc[0]})\n{selected_flight.loc[:, 'out_nb_stops'].iloc[0]}, {selected_flight.loc[:, 'out_company'].iloc[0]}\nCHF {(selected_flight.loc[:, 'flight_price'].iloc[0]/2):.2f} per flight"
        timetable.loc[:out_arr_time, out_arr_date] = f"{selected_flight.loc[:, 'out_from_airport'].iloc[0]} - {selected_flight.loc[:, 'out_to_airport'].iloc[0]}\n{selected_flight.loc[:, 'out_dep_time'].iloc[0]} - {selected_flight.loc[:, 'out_arr_time'].iloc[0]} ({selected_flight.loc[:, 'out_duration'].iloc[0]})\n{selected_flight.loc[:, 'out_nb_stops'].iloc[0]}, {selected_flight.loc[:, 'out_company'].iloc[0]}\nCHF {(selected_flight.loc[:, 'flight_price'].iloc[0]/2):.2f} per flight"

    
    # Empty all cells before the incoming flight and after the leaving flight, to get rid of impossible activities
    timetable.loc[:in_dep_time, in_dep_date] = np.nan
    timetable.loc[out_arr_time:, out_arr_date] = np.nan
    
    timetable.fillna('---', inplace = True)
    
    # Style the timetable
    style_table(timetable, date_trip_begin, date_trip_end, color1, color2)
    

# MAIN FUNCTION

def flyhigh(city_departure,
            country_departure,
            date_trip_begin,
            date_trip_end,
            nb_adults,
            nb_children,
            nb_rooms,
            city_arrival,
            cabin_class,
            range_stars,
            stops,
            max_budget,
            information):

    # Rerun the select_schedule function in case of website-specific errors, such as booking blocking at a
    # specific location, restaurants not giving crucial values because of booking not loading properly, ...

    selected_flight, selected_hotel, selected_activities, selected_restaurants = select_schedule(
                        city_departure, country_departure, date_trip_begin,
                        date_trip_end, nb_adults, nb_children, nb_rooms,
                        city_arrival, cabin_class, range_stars, stops,
                        max_budget, information)

    
    create_timetable(selected_flight, selected_hotel, selected_activities,
                     selected_restaurants, date_trip_begin, date_trip_end)

def minigame():
    
    # Retrieve a list of all the countries in the world
    countries = list(pycountry.countries)

    # Create a dictionary mapping country codes to flag image paths
    flags_dict = {}
    for country in countries:
        code = country.alpha_2.lower()
        flag_path = os.path.join("flags", f"{code}.png")
        flags_dict[code] = flag_path

    # Create the main window with a flag image, a guess input, a submit button and a score
    layout = [
        [sg.Column([[sg.Image(key='flag_image', size=(200, 200))]], justification='center')],
        [sg.Column([[sg.Text('Guess the country: '), sg.Input(key='input_guess'), sg.Button('Submit', key='submit_guess')]], justification='center')],
        [sg.Text('', size=(40, 1), key='output_guess', text_color='black')],
        [sg.Text(''), sg.Text('0', key='score')]
    ]

    window = sg.Window('Guess the flag', layout, finalize=True, size=(600, 350))

    # Load a random flag image when the program starts and initialize score
    country = random.choice(countries)
    flag_path = flags_dict[country.alpha_2.lower()]
    flag_img = Image.open(flag_path)
    flag_img = flag_img.resize((200, 200))
    flag_tk = ImageTk.PhotoImage(flag_img)
    window['flag_image'].update(data=flag_tk)
    score = 0

    # Event Loop
    while True:
        event, values = window.read()
        if event == sg.WINDOW_CLOSED:
            break
        elif event == 'submit_guess':
            guess = values['input_guess']
            if guess.title() == country.name:
                window['output_guess'].update('Correct!', text_color='green')
                score += 1
            else:
                window['output_guess'].update(f"Incorrect! The right answer was: {country.name}", text_color='red')
                score -= 1
            # Update the score and load a new flag image
            window['score'].update(f'Score: {score}')
            country = random.choice(countries)
            flag_path = flags_dict[country.alpha_2.lower()]
            flag_img = Image.open(flag_path)
            flag_img = flag_img.resize((200, 200))
            flag_tk = ImageTk.PhotoImage(flag_img)
            window['flag_image'].update(data=flag_tk)
            window['input_guess'].update('')

    window.close()

# TESTING


"""
# Define all parameters
city_departure = 'Paris'
country_departure = 'France'
date_trip_begin = '2023-08-12'
date_trip_end = '2023-08-22'
nb_adults = 2
nb_children = 2
nb_rooms = 2
city_arrival = 'Budapest'
cabin_class = 'ECONOMY'
range_stars = [4, 5]
stops = False
max_budget = '15000'


# Run selection
selected_flight, selected_hotel, selected_activities, selected_restaurants = select_schedule(
                            city_departure, country_departure, date_trip_begin,
                            date_trip_end, nb_adults, nb_children, nb_rooms,
                            city_arrival, cabin_class, range_stars, stops,
                            max_budget)



# Run this section to test the timetable and styling part

total_cost = '2700' # randomly set value, since it is for testing and it is just printed

selected_flight = pd.read_csv('selected_flight.csv')
selected_hotel = pd.read_csv('selected_hotel.csv')
selected_activities = pd.read_csv('selected_activities.csv')
selected_restaurants = pd.read_csv('selected_restaurants.csv')

create_timetable(selected_flight, selected_hotel, selected_activities,
                 selected_restaurants, date_trip_begin, date_trip_end)



# Run this section to test the entire thing
flyhigh(city_departure,
        country_departure,
        date_trip_begin,
        date_trip_end,
        nb_adults,
        nb_children,
        nb_rooms,
        city_arrival,
        cabin_class,
        range_stars,
        stops,
        max_budget,
        information=None)
"""

