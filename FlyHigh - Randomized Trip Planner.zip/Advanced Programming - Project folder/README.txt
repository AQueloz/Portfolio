FLYHIGH
=============

FlyHigh is a Python program that generates a fully customized travel itinerary based on user input. It employs a pseudo-random selection algorithm to determine the destination, flights, hotels, restaurants, and activities. It uses scraped data from two popular websites, namely booking.com and tripadvisor.com. Once the search results are obtained, the program filters them based on the user's preferences and budget constraints. The final itinerary is presented as a two-page PDF file, including a personalized travel schedule, travel recommendations, and booking URLs. The program's user interface, web-scraping capabilities, and browser simulation functionality are supported by PySimpleGUI, BeautifulSoup, and Selenium, respectively.


Installation
------------

The required list of libraries are :
	→ os
	→ pandas
	→ pycountry
	→ PySimpleGUI
	→ time
	→ threading
	→ PIL (Python Imaging Library)
	→ excel2img
	→ haversine
	→ numpy
	→ openpyxl
	→ random
	→ requests
	→ bs4 (BeautifulSoup)
	→ datetime
	→ openpyxl
	→ reportlab
	→ selenium
	→ webdriver_manager.chrome (ChromeDriverManager)

Other essentiel prerequisites for the program to run smoothly :

	→ Allowing your computer / Chrome to access your current location (booking.com requirement)
	→ Having a "Swiss-based" computer (to avoid currency changes in computation; in our case, it will lead to empty DataFrames because of euro signs,making sure that no calculation would be computed with different currencies). This means having all prices written in CHF by default on websites, such as booking.com and tripadvisor.com
	→ Having a good internet speed. Since the program waits for webpages to load, if they do not load within the given time, the program will not run properly.


Usage
-----

Run the program by simply running the "fly_high.py" Python script. The "supporting_functions.py" script as well as other folders have to be in the same directory.

